﻿---
name: reference-index
description: 在完成初步 GH 建模逻辑规划之后查阅；仅当条目与已定方案相关时，再调用 read_reference_json 读取 JSON 对照实现。若 reference_metadata.csharp_scripts 存在，应优先检查其中 C# 代码。
---

# Reference Index

使用流程：
1. 先规划：用简短步骤说明本任务的 GH 逻辑（数据流、关键电池、风险点等）。
2. 再浏览：查阅下列参考条目，看是否与**已定方案**高度相关。
3. 后读取：若相关，调用 `read_reference_json` 并传入对应 `file_name`，用 JSON 对齐细节、补充或改造实现；若条目含 `技能：skills/official_*_csharp.md`，先用 `read_skill_file` 读取官方拆分后的 C# 代码；若 JSON 含 `reference_metadata.csharp_scripts`，也要检查其中代码、端口和用途。
4. 只有在 C# Script 的具体 RhinoCommon/Grasshopper SDK API 不确定、已有 API 编译错误、涉及 RhinoDoc/Bake/图层/标注/Clipping 等高风险文档操作，或用户明确要求官方 API 查证时，才读取 `skills/official_rhinocommon_api_reference.md`；普通建模和已有 reference/skill 可复用时不要默认读取或联网搜索。

## References
- 描述：建筑轴网 + 轴线尺寸标注组合流程（例如“创建5*5轴网并标注”“轴网并标注”“轴线标注”）。必须读取两个技能并导入两个 GH：先导入 reference/axis.gh 生成 AxisDimensions，再导入 reference/dimension.gh，把 Axis.AxisDimensions 接到 Dimensions.AxisDimensions，最终使用 AdjustedDimensions。
  文件：reference/axis.gh + reference/dimension.gh
  调用：先 read_skill_file("official_rhino_axis_grid_csharp.md")，再 read_skill_file("official_rhino_axis_dimension_adjust_csharp.md")，然后通过宿主 reference GH 导入流程分别导入 `axis.gh` 和 `dimension.gh`
  技能：skills/official_rhino_axis_grid_csharp.md + skills/official_rhino_axis_dimension_adjust_csharp.md
- 描述：建筑轴线/轴网绘制（轴线、轴号泡泡、轴线尺寸标注、端点输出，支持斜交轴网和逐跨间距）
  文件：reference/axis.gh
  调用：通过宿主内部 reference GH 导入流程导入 `axis.gh`
  技能：skills/official_rhino_axis_grid_csharp.md
- 描述：建筑轴线尺寸标注二次调整（接收 axis.gh 的 AxisDimensions 输出，调整文字高度、模型空间比例、尺寸线距离和内外尺寸间距）
  文件：reference/dimension.gh
  调用：通过宿主内部 reference GH 导入流程导入 `dimension.gh`
  技能：skills/official_rhino_axis_dimension_adjust_csharp.md
- 描述：逐跨尺寸与总尺寸自动标注（含尺寸界线、箭头、标注文字，偏移可调）
  文件：reference/official_annotation_dimension_csharp.json
  调用：read_reference_json(file_name="official_annotation_dimension_csharp.json")
  技能：skills/official_rhino_annotation_dimension_csharp.md
- 描述：基于 C# Script 的 ClippingDrawing 批量自动化出图工作流
  文件：reference/official_clippingdrawing_batch_csharp.json
  调用：read_reference_json(file_name="official_clippingdrawing_batch_csharp.json")
  技能：skills/official_rhino_clippingdrawing_batch_csharp.md

## API Skills
- 描述：低频 RhinoCommon / Grasshopper C# 官方 API 查证流程；仅在 API 签名不确定、API 编译错误、高风险 Rhino 文档操作或用户明确要求官方查证时使用。普通 GH 建模不要默认触发。
  技能：skills/official_rhinocommon_api_reference.md
